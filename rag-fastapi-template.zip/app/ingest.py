import os
import glob
from qdrant_client import QdrantClient
from qdrant_client.http.models import PointStruct
from app.utils import embed_text
from dotenv import load_dotenv

load_dotenv()

qdrant = QdrantClient(url=os.getenv("QDRANT_URL"))
collection_name = os.getenv("QDRANT_COLLECTION")

def load_documents(directory):
    documents = []
    for filepath in glob.glob(f"{directory}/*.txt"):
        with open(filepath, "r", encoding="utf-8") as f:
            documents.append(f.read())
    return documents

def chunk_text(text, chunk_size=500):
    return [text[i:i+chunk_size] for i in range(0, len(text), chunk_size)]

def main():
    documents = load_documents("data/sample_docs")
    points = []
    id_counter = 0

    for doc in documents:
        chunks = chunk_text(doc)
        for chunk in chunks:
            embedding = embed_text(chunk)
            points.append(PointStruct(id=id_counter, vector=embedding, payload={"text": chunk}))
            id_counter += 1

    qdrant.upsert(collection_name=collection_name, points=points)

if __name__ == "__main__":
    main()
