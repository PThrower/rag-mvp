# RAG FastAPI Template

This is a starter project for a Retrieval-Augmented Generation (RAG) API using FastAPI, Qdrant, and OpenAI.

## Features

- Embeds and indexes documents using OpenAI
- Stores embeddings in Qdrant
- FastAPI endpoint to query documents using RAG
- Easy deployment ready

## Usage

1. Fill in your `.env` file with the correct credentials.
2. Run `ingest.py` to embed and upload documents.
3. Start the FastAPI server with `uvicorn app.main:app --reload`.
