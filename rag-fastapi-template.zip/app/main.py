import os
from fastapi import FastAPI
from pydantic import BaseModel
from dotenv import load_dotenv
from openai import OpenAI
from qdrant_client import QdrantClient

load_dotenv()
app = FastAPI()

openai = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
qdrant = QdrantClient(url=os.getenv("QDRANT_URL"))
COLLECTION_NAME = os.getenv("QDRANT_COLLECTION")

class Query(BaseModel):
    question: str

@app.post("/chat")
async def chat(query: Query):
    question = query.question
    embedding = openai.embeddings.create(model=os.getenv("EMBEDDING_MODEL"), input=question).data[0].embedding

    search_result = qdrant.search(collection_name=COLLECTION_NAME, query_vector=embedding, limit=3)
    context_chunks = [point.payload.get("text", "") for point in search_result]

    prompt = (
        "You are a helpful assistant. Use the following context to answer the question.

"
        f"Context:
{chr(10).join(context_chunks)}

"
        f"Question: {question}
Answer:"
    )

    completion = openai.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": "You answer based only on the provided context."},
            {"role": "user", "content": prompt}
        ],
        max_tokens=300,
        temperature=0.0,
    )

    return {"answer": completion.choices[0].message.content.strip()}
